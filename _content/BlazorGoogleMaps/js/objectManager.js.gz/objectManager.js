﻿window.blazorGoogleMaps = window.blazorGoogleMaps || function () {
    function stringToFunction(str) {
        const arr = str.split(".");
        let fn = window || this;

        for (const key of arr) {
            if (fn[key] === undefined) {
                throw new Error(`Property '${key}' not found`);
            }
            fn = fn[key];
        }

        if (typeof fn !== "function") {
            throw new TypeError("Function not found");
        }

        return fn;
    }


    const extendableStringify = (obj, replacer, space) => {
        const beforeStringify = window?.blazorGoogleMapsBeforeStringify || this?.blazorGoogleMapsBeforeStringify;
        if (typeof beforeStringify === 'function') {
            obj = beforeStringify(obj);
        }
        return JSON.stringify(obj, replacer, space);
    };

    let mapObjects = {};
    let controlParents = {};
    let polygonClickListeners = new Map();
    let polygonDragListeners = new Map();
    const dateFormat = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/;

    // The lookups below translate the strings sent from .NET into Google Maps enum values.
    // They are built on first use (the Google Maps API is not loaded yet when this script runs)
    // and then reused, instead of being rebuilt on every call.
    function lazy(build) {
        let value;
        return () => value || (value = build());
    }

    const getOverlayTypeLookup = lazy(() => ({
        "google.maps.drawing.OverlayType.CIRCLE": google.maps.drawing.OverlayType.CIRCLE,
        "google.maps.drawing.OverlayType.MARKER": google.maps.drawing.OverlayType.MARKER,
        "google.maps.drawing.OverlayType.POLYGON": google.maps.drawing.OverlayType.POLYGON,
        "google.maps.drawing.OverlayType.POLYLINE": google.maps.drawing.OverlayType.POLYLINE,
        "google.maps.drawing.OverlayType.RECTANGLE": google.maps.drawing.OverlayType.RECTANGLE
    }));

    const getAnimationLookup = lazy(() => ({
        "google.maps.Animation.DROP": google.maps.Animation.DROP,
        "google.maps.Animation.BOUNCE": google.maps.Animation.BOUNCE
    }));

    const getSymbolPathLookup = lazy(() => ({
        "BACKWARD_CLOSED_ARROW": google.maps.SymbolPath.BACKWARD_CLOSED_ARROW,
        "BACKWARD_OPEN_ARROW": google.maps.SymbolPath.BACKWARD_OPEN_ARROW,
        "CIRCLE": google.maps.SymbolPath.CIRCLE,
        "FORWARD_CLOSED_ARROW": google.maps.SymbolPath.FORWARD_CLOSED_ARROW,
        "FORWARD_OPEN_ARROW": google.maps.SymbolPath.FORWARD_OPEN_ARROW,
    }));

    const getCollisionBehaviorLookup = lazy(() => ({
        "google.maps.CollisionBehavior.REQUIRED": google.maps.CollisionBehavior.REQUIRED,
        "google.maps.CollisionBehavior.REQUIRED_AND_HIDES_OPTIONAL": google.maps.CollisionBehavior.REQUIRED_AND_HIDES_OPTIONAL,
        "google.maps.CollisionBehavior.OPTIONAL_AND_HIDES_LOWER_PRIORITY": google.maps.CollisionBehavior.OPTIONAL_AND_HIDES_LOWER_PRIORITY
    }));

    const getRenderingTypeLookup = lazy(() => ({
        "google.maps.RenderingType.RASTER": google.maps.RenderingType.RASTER,
        "google.maps.RenderingType.UNINITIALIZED": google.maps.RenderingType.UNINITIALIZED,
        "google.maps.RenderingType.VECTOR": google.maps.RenderingType.VECTOR
    }));

    const getTravelModeLookup = lazy(() => ({
        "BICYCLING": google.maps.TravelMode.BICYCLING,
        "DRIVING": google.maps.TravelMode.DRIVING,
        "TRANSIT": google.maps.TravelMode.TRANSIT,
        "WALKING": google.maps.TravelMode.WALKING,
    }));

    //https://developers.google.com/maps/documentation/javascript/reference/control#ControlPosition
    const getControlPositionLookup = lazy(() => ({
        "BOTTOM_CENTER": google.maps.ControlPosition.BOTTOM_CENTER,
        "BOTTOM_LEFT": google.maps.ControlPosition.BOTTOM_LEFT,
        "BOTTOM_RIGHT": google.maps.ControlPosition.BOTTOM_RIGHT,
        "LEFT_BOTTOM": google.maps.ControlPosition.LEFT_BOTTOM,
        "LEFT_CENTER": google.maps.ControlPosition.LEFT_CENTER,
        "LEFT_TOP": google.maps.ControlPosition.LEFT_TOP,
        "RIGHT_BOTTOM": google.maps.ControlPosition.RIGHT_BOTTOM,
        "RIGHT_CENTER": google.maps.ControlPosition.RIGHT_CENTER,
        "RIGHT_TOP": google.maps.ControlPosition.RIGHT_TOP,
        "TOP_CENTER": google.maps.ControlPosition.TOP_CENTER,
        "TOP_LEFT": google.maps.ControlPosition.TOP_LEFT,
        "TOP_RIGHT": google.maps.ControlPosition.TOP_RIGHT
    }));

    // JSON.parse can only succeed when the text starts like a JSON value. Plain strings such as
    // event names ("click") never do, so they can skip the guaranteed exception.
    function mayBeJson(text) {
        return /^\s*(?:[{\["\-\d]|true|false|null)/.test(text);
    }

    function mayBeObjectLiteral(text) {
        return /^\s*[{\[]/.test(text);
    }

    // Replaces a named symbol path ("CIRCLE") in holder.icon with its google.maps.SymbolPath value.
    // Anything else, such as a custom SVG path or an icon given as an url, is left as it is.
    function resolveSymbolPath(holder) {
        const icon = holder && holder.icon;
        if (!icon || typeof icon !== "object" || !icon.path) {
            return;
        }

        const symbolPathLookup = getSymbolPathLookup();
        if (Object.prototype.hasOwnProperty.call(symbolPathLookup, icon.path)) {
            icon.path = symbolPathLookup[icon.path];
        }
    }


    // Add the object to the map for "managed" objects, tries to set the guidString to
    // be able to dispose of them later on
    function addMapObject(uuid, obj) {
        if (obj && typeof(obj) === "object" && "set" in obj) {
            obj.set("guidString", uuid);
        }
        mapObjects[uuid] = obj;
    }

    //Strip circular dependencies, map object and functions
    //https://stackoverflow.com/questions/11616630/how-can-i-print-a-circular-structure-in-a-json-like-format
    const getCircularReplacer = () => {
        const seen = new WeakSet();
        return (key, value) => {
            if (key == "map") return undefined;
            if (typeof value == 'function') return undefined;

            if (typeof value === "object" && value !== null) {
                if (seen.has(value)) {
                    return;
                }
                seen.add(value);
            }
            return value;
        };
    };

    function dateObjectReviver(key, value) {
        if (typeof value === "string" && dateFormat.test(value)) {
            return new Date(value);
        }
        return value;
    }


    function tryParseJson(item) {
        // Check if the item is a DotNet object reference with the "invokeMethodAsync" method
        if (item !== null && typeof item === "object" && "invokeMethodAsync" in item) {
            return async function (...args) {
                // The event argument is registered only for the duration of the .NET call
                const guid = blazorGoogleMaps.objectManager.addObject(args[0]);

                const hasMarker = args.length === 1 && args[0] != null && typeof args[0].marker !== "undefined";
                const markerBackup = hasMarker ? args[0].marker : undefined;

                try {
                    if (hasMarker) {
                        args[0].marker = null;
                    }
                    else if (args.length === 1 && args[0] instanceof Object && "feature" in args[0]) {
                        args[0].featureUUID = args[0].feature.getProperty("UUID");
                    }

                    await item.invokeMethodAsync("Invoke", extendableStringify(args, getCircularReplacer()), guid);
                } finally {
                    // Also runs when the .NET call fails (e.g. the circuit is gone), so nothing is left behind
                    if (hasMarker) {
                        args[0].marker = markerBackup;
                    }

                    blazorGoogleMaps.objectManager.disposeObject(guid);
                }
            };
        }

        if (typeof item !== "string") {
            return item;
        }

        let parsedItem;
        let isParsed = false;

        if (mayBeJson(item)) {
            try {
                parsedItem = JSON.parse(item, dateObjectReviver);
                isParsed = true;
            } catch (e) {
                // Not valid JSON, use the fallback below
            }
        }

        if (!isParsed) {
            if (item.startsWith("google.maps.drawing.OverlayType")) {
                try {
                    return getOverlayTypeLookup()[item] || item;
                } catch (e) {
                    // The drawing library is not loaded
                    return item;
                }
            }

            // Everything else that is not JSON is plain text, such as an event name or a title,
            // and is returned as it is. It must never be run as code.
            if (!mayBeObjectLiteral(item)) {
                return item;
            }

            try {
                // Fallback to using eval to handle object literals that are not strict JSON,
                // e.g. options with functions in them
                parsedItem = eval(`(${item})`);
            } catch (e2) {
                // Return the item as is if parsing fails
                return item;
            }
        }

        if (typeof parsedItem === "object" && parsedItem !== null) {
            if ("guidString" in parsedItem) {
                return mapObjects[parsedItem.guidString];
            } else {
                for (let propertyName in parsedItem) {
                    let propertyValue = parsedItem[propertyName];

                    // Convert specific Google Maps Animation strings to their corresponding objects
                    if (typeof propertyValue === "string" && propertyValue.startsWith("google.maps.Animation")) {
                        parsedItem[propertyName] = getAnimationLookup()[propertyValue] || propertyValue;
                    }

                    if (propertyName == "icons" || propertyName == "markerOptions") {
                        if (Array.isArray(propertyValue)) {
                            propertyValue.forEach(iconHolder => resolveSymbolPath(iconHolder));
                        } else {
                            resolveSymbolPath(propertyValue);
                        }
                    }

                    // Convert specific Google Maps CollisionBehavior strings to their corresponding objects
                    if (typeof propertyValue === "string" && propertyValue.startsWith("google.maps.CollisionBehavior")) {
                        parsedItem[propertyName] = getCollisionBehaviorLookup()[propertyValue] || propertyValue;
                    }

                    // Convert position strings to Google Maps positions
                    if (typeof propertyValue === "object" && propertyValue !== null && propertyValue.position !== undefined) {
                        propertyValue.position = getGooglePositionFromString(propertyValue.position);
                    }

                    if (propertyName === "renderingType" && propertyValue !== null) {
                        parsedItem[propertyName] = getRenderingTypeLookup()[propertyValue] || google.maps.RenderingType.RASTER;
                    }

                    if (propertyName === "travelMode" && propertyValue !== null) {
                        parsedItem[propertyName] = getTravelModeLookup()[propertyValue] || google.maps.TravelMode.DRIVING;
                    }
                    // Handle nested drawingModes property
                    if (typeof propertyValue === "object" && propertyValue !== null && "drawingModes" in propertyValue) {
                        const drawingModeMapping = getOverlayTypeLookup();

                        propertyValue.drawingModes = propertyValue.drawingModes.map(drawingMode => drawingModeMapping[drawingMode] || drawingMode);
                    }

                    // Handle nested objects with a guidString property
                    if (typeof propertyValue === "object" && propertyValue !== null && "guidString" in propertyValue) {
                        parsedItem[propertyName] = mapObjects[propertyValue.guidString];
                    }
                }
                return parsedItem;
            }
        }

        return item.replace(/['"]+/g, '');
    }


    function uuidv4() {
        // Native and much faster, but only available in secure contexts (https, localhost)
        if (typeof crypto.randomUUID === "function") {
            return crypto.randomUUID();
        }

        return ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, c =>
            (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
        );
    }


    //Strips the DirectionResult from some of the heaviest collections.
    //ServerSide (Client Side have no issues) reach MaximumReceiveMessageSize (32kb) and crash if we return all data
    //Workaround is to increase limit MaximumReceiveMessageSize
    //The heavy collections are dropped before the result is serialized (only the levels that change are copied,
    //the original result is left untouched), so they are never stringified just to be thrown away.
    function cleanDirectionResult(dirResponse, dirRequestOptions) {
        const stripAll = dirRequestOptions == undefined;
        const stripOverviewPath = stripAll || dirRequestOptions.stripOverviewPath;
        const stripOverviewPolyline = stripAll || dirRequestOptions.stripOverviewPolyline;
        const stripLegsSteps = stripAll || dirRequestOptions.stripLegsSteps;
        const stripLegsStepsLatLngs = stripAll || dirRequestOptions.stripLegsStepsLatLngs;
        const stripLegsStepsPath = stripAll || dirRequestOptions.stripLegsStepsPath;

        const routes = dirResponse.routes.map((r) => {
            const route = { ...r };

            if (stripOverviewPath) {
                route.overview_path = [];
            }

            if (stripOverviewPolyline) {
                route.overview_polyline = ''; // overview_polyline is a string, not an array
            }

            route.legs = r.legs.map((l) => {
                const leg = { ...l };

                if (stripLegsSteps) {
                    leg.steps = [];
                } else {
                    leg.steps = l.steps.map((s) => {
                        const step = { ...s };

                        if (stripLegsStepsLatLngs) {
                            step.lat_lngs = [];
                        }

                        if (stripLegsStepsPath) {
                            step.path = [];
                        }

                        return step;
                    });
                }

                return leg;
            });

            return route;
        });

        return { ...dirResponse, routes };
    }


    function getGooglePositionFromString(positionString) {
        // Return the corresponding ControlPosition or default to BOTTOM_CENTER if not found
        return getControlPositionLookup()[positionString] || google.maps.ControlPosition.BOTTOM_CENTER;
    }

    let directionService = {
        route: async function (request, options) {
            let renderer = this;

            let promise = new Promise((resolve, reject) => {
                let directionsService = new google.maps.DirectionsService();
                directionsService.route(request, (result, status) => {
                    if (status == 'OK') {
                        resolve(result);
                    } else {
                        reject(status);
                    }
                });
            });

            try {
                let result = await promise;

                if (typeof renderer.setDirections === "function") {
                    renderer.setDirections(result);
                }

                let jsonRest = extendableStringify(cleanDirectionResult(result, options));
                return jsonRest;
            } catch (error) {
                console.log(error);
                return error;
            }
        }
    };


    //It is impossible to pass to pass HTMLElement from blazor to google maps
    //Due to this we need to create it in js side.
    function getAdvancedMarkerElementContent(functionName, content) {
        if (functionName === "google.maps.marker.AdvancedMarkerView" || functionName === "google.maps.marker.AdvancedMarkerElement") {
            if (content) {
                //Old code. It work when creating with options but not when SetContent
                //let isPinElement = content.dotnetTypeName === "GoogleMapsComponents.Maps.PinElement";
                const isHtmlContent = typeof content === 'string' && content.startsWith("<");

                if (isHtmlContent) {
                    let template = document.createElement('template');
                    template.innerHTML = content.trim();
                    return template.content.firstChild;
                } else {
                    const pinOptions = {
                        background: content.background,
                        borderColor: content.borderColor,
                        glyphColor: content.glyphColor,
                        scale: content.scale
                    };

                    if (content.glyphText) {
                        pinOptions.glyphText = content.glyphText;
                    }

                    if (content.glyphSrc) {
                        pinOptions.glyphSrc = content.glyphSrc;
                    }

                    let pin = new google.maps.marker.PinElement(pinOptions);

                    let glyph = content.glyph;
                    if (glyph && !content.glyphText && !content.glyphSrc) {
                        const isGlyphHtmlContent = typeof glyph === 'string' && glyph.startsWith("<");
                        if (isGlyphHtmlContent) {
                            let template = document.createElement('div');
                            template.innerHTML = glyph.trim();
                            pin.glyph = template;
                        } else if (typeof glyph === 'string' && glyph.startsWith("http")) {
                            if ("glyphSrc" in pin) {
                                pin.glyphSrc = glyph;
                            } else {
                                pin.glyph = new URL(glyph);
                            }
                        } else if (typeof glyph === 'string') {
                            if ("glyphText" in pin) {
                                pin.glyphText = glyph;
                            } else {
                                pin.glyph = glyph;
                            }
                        } else {
                            pin.glyph = glyph;
                        }
                    }

                    return pin.element;
                }
            }
        }

        return null;
    }

    function isPlaceAutocompleteElement(obj) {
        const placeAutocompleteCtor = google?.maps?.places?.PlaceAutocompleteElement;
        if (placeAutocompleteCtor && obj instanceof placeAutocompleteCtor) {
            return true;
        }
        return obj && obj.tagName && obj.tagName.toLowerCase() === "gmp-place-autocomplete";
    }

    function mapPlacePrediction(prediction) {
        if (!prediction) return null;
        const normalizeTextValue = (value) => {
            if (value === null || typeof value === "undefined") return null;
            if (typeof value === "string") return value;
            if (typeof value === "object") {
                if (typeof value.text === "string") return value.text;
                if (typeof value.value === "string") return value.value;
            }
            return null;
        };

        return {
            distanceMeters: prediction.distanceMeters ?? prediction.distanceInMeters ?? null,
            mainText: normalizeTextValue(prediction.mainText ?? prediction.structuredFormatting?.mainText),
            secondaryText: normalizeTextValue(prediction.secondaryText ?? prediction.structuredFormatting?.secondaryText),
            text: normalizeTextValue(prediction.text ?? prediction.description),
            placeId: prediction.placeId ?? prediction.place_id ?? null,
            types: prediction.types ?? null
        };
    }

    function normalizeLatLngLiteral(value) {
        if (!value) return null;
        if (typeof value.lat === "function" && typeof value.lng === "function") {
            return { lat: value.lat(), lng: value.lng() };
        }
        if (typeof value.lat === "number" && typeof value.lng === "number") {
            return { lat: value.lat, lng: value.lng };
        }
        return null;
    }

    function normalizeDisplayName(value) {
        if (!value) return null;
        if (typeof value === "string") return value;
        if (typeof value === "object") {
            if (typeof value.text === "string") return value.text;
            if (typeof value.value === "string") return value.value;
        }
        return null;
    }

    function normalizePlaceObject(place) {
        if (!place || typeof place !== "object") return place;
        const findLatLngInObject = (obj, depth) => {
            if (!obj || typeof obj !== "object" || depth > 2) return null;
            for (const key of Object.keys(obj)) {
                const value = obj[key];
                const direct = normalizeLatLngLiteral(value);
                if (direct) return direct;
                if (value && typeof value === "object") {
                    const nested = findLatLngInObject(value, depth + 1);
                    if (nested) return nested;
                }
            }
            return null;
        };

        const location = normalizeLatLngLiteral(place.location)
            ?? normalizeLatLngLiteral(place.geometry?.location)
            ?? findLatLngInObject(place, 0);
        const displayName = normalizeDisplayName(place.displayName)
            ?? normalizeDisplayName(place.name);
        return {
            id: place.id ?? place.placeId ?? place.place_id ?? null,
            requestedLanguage: place.requestedLanguage ?? null,
            requestedRegion: place.requestedRegion ?? null,
            displayName: displayName,
            location: location
        };
    }

    function buildPlaceAutocompleteEventPayload(event) {
        const prediction = event?.placePrediction ?? event?.detail?.placePrediction;
        if (prediction) {
            return { placePrediction: mapPlacePrediction(prediction) };
        }
        return event;
    }


    return {
        objectManager: {
            get mapObjects() { return mapObjects; },
            initMap: async function (apiOptions) {
                const librariesToLoad = apiOptions["libraries"];
                delete apiOptions["libraries"];

                (g => { var h, a, k, p = "The Google Maps JavaScript API", c = "google", l = "importLibrary", q = "__ib__", m = document, b = window; b = b[c] || (b[c] = {}); var d = b.maps || (b.maps = {}), r = new Set, e = new URLSearchParams, u = () => h || (h = new Promise(async (f, n) => { await (a = m.createElement("script")); e.set("libraries", [...r] + ""); for (k in g) e.set(k.replace(/[A-Z]/g, t => "_" + t[0].toLowerCase()), g[k]); e.set("callback", c + ".maps." + q); a.src = `https://maps.${c}apis.com/maps/api/js?` + e; d[q] = f; a.onerror = () =>{ h = n(Error(p + " could not load.")); try { a.remove(); } catch {} try { delete d[q]; } catch {} try { delete d[l]; } catch {} try { h = undefined; } catch {} }; a.nonce = m.querySelector("script[nonce]")?.nonce || ""; m.head.append(a) })); d[l] ? console.warn(p + " only loads once. Ignoring:", g) : d[l] = (f, ...n) => r.add(f) && u().then(() => d[l](f, ...n)) })(
                    apiOptions
                );

                // Request all libraries at once: the loader then fetches them with a single script request
                // and loads them in parallel, instead of one network round trip after another.
                await Promise.all(librariesToLoad.split(',').map(library => google.maps.importLibrary(library)));
            },
            createImageMapType: function (baseUrlFormat, minZoom, maxZoom, name, opacity, subDomains) {
                const safeFormat = typeof baseUrlFormat === "string" ? baseUrlFormat : "";
                const hasSubDomains = Array.isArray(subDomains) && subDomains.length > 0;

                const getTileUrl = (coord, zoom) => {
                    let url = safeFormat
                        .replace("{z}", zoom)
                        .replace("{x}", coord.x)
                        .replace("{y}", coord.y);
                    if (hasSubDomains) {
                        const ndx = Math.abs(coord.y) % subDomains.length;
                        url = url.replace("{domain}", subDomains[ndx]);
                    }
                    return url;
                };

                return new google.maps.ImageMapType({
                    getTileUrl: getTileUrl,
                    tileSize: new google.maps.Size(256, 256),
                    maxZoom: maxZoom,
                    minZoom: minZoom,
                    opacity: opacity,
                    name: name
                });
            },

            createObject: function (args) {
                let args2 = args.slice(2).map(arg => tryParseJson(arg));

                let functionName = args[1];
                let advancedMarkerElementContent = getAdvancedMarkerElementContent(functionName, args2.length > 0 ? args2[0]?.content : null);
                if (advancedMarkerElementContent !== null) {
                    args2[0].content = advancedMarkerElementContent;
                }

                let obj;
                if (functionName === "google.maps.Map") {
                    const targetElement = args2[0]; // Map div
                    const options = args2[1]; // Map options
                    const recycleKey = options.recycle ? options.cacheKey + options.recycle : options.cacheKey
                    if (options.recycle && mapObjects[recycleKey]) {
                        targetElement.appendChild(mapObjects[recycleKey].div)
                        obj = mapObjects[recycleKey].map
                        obj.setOptions(options)
                    } else {
                        obj = new google.maps.Map(targetElement, options)
                        if (recycleKey)
                            mapObjects[recycleKey] = { map: obj, div: obj.getDiv() }
                    }
                    // Tag the map with the recycle key to be able to retrieve it in dispose...
                    if (recycleKey && obj && typeof(obj) === "object" && "set" in obj) {
                        obj.set("recycleKey", recycleKey);
                    }
                }
                else
                {
                    let constructor = stringToFunction(functionName);
                    obj = new constructor(...args2);
                }

                let guid = args[0];
                addMapObject(guid, obj)
            },

            //Used to create multiple objects of the same type passing a set of creation parameters coherent
            //with object we need to create
            //This allows a single JSInteropt invocation for multiple objects creation with a consistent gain
            //in terms of performance
            createMultipleObject: function (args) {
                let args2 = args.slice(2).map(arg => tryParseJson(arg));
                //console.log(args2);
                let functionName = args[1];
                let constructor = stringToFunction(functionName);

                let guids = JSON.parse(args[0]);

                for (let i = 0, len = args2.length; i < len; i++) {
                    const constructorArgs = args2[i];
                    let advancedMarkerElementContent = getAdvancedMarkerElementContent(functionName, constructorArgs.content);
                    if (advancedMarkerElementContent !== null) {
                        constructorArgs.content = advancedMarkerElementContent;
                    }

                    let obj = new constructor(constructorArgs);
                    addMapObject(guids[i], obj);
                }
            },



            addObject: function (obj, guid) {
                if (guid === null || typeof guid === "undefined") {
                    guid = uuidv4();
                }

                addMapObject(guid, obj);

                return guid;
            },

            addControls(args) {
                let mapGuid = args[0];
                let map = mapObjects[mapGuid];
                let elem = args[2];
                if (!elem) return
                //I know i am lazy. Two quotes appear after serialization
                let position = getGooglePositionFromString(args[1].replace("\"", "").replace("\"", ""));

                // check if the control already exists
                var controls = map.controls[position].getArray();
                for (var i = 0; i < controls.length; i++) {
                    if (controls[i].id === elem.id) {
                        return;
                    }
                }

                if (controlParents == null) {
                    controlParents = {}
                }
                if (controlParents.hasOwnProperty(mapGuid) == false) {
                    controlParents[mapGuid] = {}
                }
                if (controlParents[mapGuid].hasOwnProperty(elem.id) == false && !controlParents[mapGuid][elem.id]) {
                    let parentElement = elem.parentElement
                    controlParents[mapGuid][elem.id] = parentElement;
                }

                elem.style.display = "block";
                map.controls[position].push(elem);
            },
            appendControlElementToOriginalParent(mapGuid, control) {
                const parent = controlParents[mapGuid][control.id];
                if (parent) {
                    parent.appendChild(control);
                    control.style.display = "none";
                }
                delete controlParents[mapGuid][control.id];
            },
            internalRemoveControlAt(mapGuid, position, controlIndex) {
                const map = mapObjects[mapGuid];
                if (controlIndex !== -1) {
                    let control = map.controls[position].removeAt(controlIndex);
                    this.appendControlElementToOriginalParent(mapGuid, control);
                }
            },
            internalRemoveControls(mapGuid, position) {
                const map = mapObjects[mapGuid];
                for (let i = map.controls[position].length - 1; i >= 0; i--) {
                    this.internalRemoveControlAt(mapGuid, position, i);
                }
            },
            removeControl(args) {
                const mapGuid = args[0];
                const map = mapObjects[mapGuid];
                const position = getGooglePositionFromString(args[1].replace(/"/g, ""));

                const elemId = args[2].id;
                const controlIndex = map.controls[position].getArray().findIndex(control => control.id === elemId);

                this.internalRemoveControlAt(mapGuid, position, controlIndex);
            },
            removeControls(args) {
                const mapGuid = args[0];
                const position = getGooglePositionFromString(args[1].replace(/"/g, ""));
                this.internalRemoveControls(mapGuid, position);
            },
            addImageLayer(args) {
                let map = mapObjects[args[0]];
                let elem = mapObjects[args[1]];

                map.overlayMapTypes.push(elem);
            },
            removeImageLayer(args) {
                let map = mapObjects[args[0]];
                let elem = mapObjects[args[1]];

                var arr = map.overlayMapTypes.getArray();
                for (var i = 0, len = arr.length; i < len; i++) {
                    if (arr[i].name === elem.name) {
                        map.overlayMapTypes.removeAt(i);
                        return;
                    }
                }
            },
            removeAllImageLayers(args) {
                let map = mapObjects[args[0]];

                var arr = map.overlayMapTypes.clear();
            },
            disposeMapElements(mapGuid) {
                const keysToRemove = [];

                for (const key in mapObjects) {
                    if (mapObjects.hasOwnProperty(key)) {
                        const element = mapObjects[key];
                        if (
                            element !== null && typeof element === "object" && // Skip entries that cannot have properties (undefined, primitives)
                            "guidString" in element && // Element has a guidString property (inherited is important for advanced marker)
                            "map" in element && // Element has a map property (inherited is important for advanced marker)
                            element.map && // Element has a map
                            "guidString" in element.map && // Map has a guidString
                            element.map.guidString === mapGuid // The guidString is matching our current guidString
                        ) {
                            keysToRemove.push(element.guidString);
                        }
                    }
                }
                // Only recycled maps need their elements detached, so check that once instead of per element
                const mapObject = mapObjects[mapGuid];
                const isRecycledMap = mapObject !== null && typeof mapObject === "object" && "recycleKey" in mapObject;

                for (const keyToRemove of keysToRemove) {
                    if (isRecycledMap) {
                        const elementToRemove = mapObjects[keyToRemove];
                        // When we dispose advanced markers and we use recycled maps, make sure to set remove them from the map.
                        if (google.maps.marker && elementToRemove instanceof google.maps.marker.AdvancedMarkerElement)
                            elementToRemove.map = null;
                        //the same for polygons, we need to remove them from the map
                        if (google.maps.Polygon && elementToRemove instanceof google.maps.Polygon)
                            elementToRemove.setMap(null);
                        //the same for heatmap layers, we need to remove them from the map
                        if (google.maps.visualization && elementToRemove instanceof google.maps.visualization.HeatmapLayer) {
                            elementToRemove.setMap(null);
                        }
                    }

                    delete mapObjects[keyToRemove];
                }

                if (controlParents !== null && controlParents.hasOwnProperty(mapGuid)) {
                    const map = mapObjects[mapGuid];
                    for (let position in map.controls) {
                        this.internalRemoveControls(mapGuid, position);
                    }
                    delete controlParents[mapGuid];
                }

                if (controlParents !== null && Object.keys(controlParents) === 0) {
                    controlParents = null;
                }
            },

            disposeObject: function (guid) {
                const object = mapObjects[guid];
                if (object instanceof google.maps.Map) {
                    // store the div.
                    const recycleKey = object["recycleKey"]
                    if (recycleKey && mapObjects[recycleKey]) {
                        mapObjects[recycleKey].div = object.getDiv()
                    }
                }
                delete mapObjects[guid];
            },

            disposeMultipleObjects: function (guids) {
                for (var i = 0, len = guids.length; i < len; i++) {
                    this.disposeObject(guids[i]);
                }
            },

            isGoogleMapsReady: function () {
                return typeof google !== "undefined"
                    && google.maps
                    && typeof google.maps.Map === "function";
            },

            invokeProperty: async function (args) {
                const args2 = args.slice(2).map(arg => tryParseJson(arg));
                const obj = mapObjects[args[0]];
                const functionToInvoke = args[1];

                const processedArgs = args2.map(element => {
                    if (element && element.hasOwnProperty("lat") && element.hasOwnProperty("lng")) {
                        return new google.maps.LatLng(element.lat, element.lng);
                    }
                    return element;
                });

                // Could be an issue in future. Currently, it is used by AdvancedMarkerElement
                const advancedMarkerElementContent = getAdvancedMarkerElementContent(
                    "google.maps.marker.AdvancedMarkerElement",
                    functionToInvoke === "content" ? processedArgs[0] : null
                );
                if (advancedMarkerElementContent !== null) {
                    processedArgs[0] = advancedMarkerElementContent;
                }

                try {
                    if (processedArgs.length > 0) {
                        obj[functionToInvoke] = processedArgs[0]
                    } else {
                        const result = obj[functionToInvoke];
                        if (result && typeof result === "object") {
                            return JSON.parse(extendableStringify(result, getCircularReplacer()));
                        } else {
                            return result;
                        }
                    }
                } catch (e) {
                    console.error(`Error invoking property: Function: ${functionToInvoke} Arguments: ${JSON.stringify(processedArgs)} Error: ${e}`);
                }
            },

            //parsedRestArgs is only passed by the batch functions below: they have parsed the arguments
            //already, once for the whole batch, so they are not parsed again for every object
            invoke: async function (args, parsedRestArgs) {
                const [objectId, functionToInvoke, ...restArgs] = args;
                const obj = mapObjects[objectId];
                const args2 = parsedRestArgs || restArgs.map(arg => tryParseJson(arg));

                if (!obj) {
                    if (functionToInvoke === "remove") {
                        this.disposeObject(objectId);
                        return null;
                    }
                    return null;
                }

                // Handle LatLng objects
                const formattedArgs = args2.map(arg => {
                    if (arg && arg.hasOwnProperty("lat") && arg.hasOwnProperty("lng")) {
                        return new google.maps.LatLng(arg.lat, arg.lng);
                    }
                    return arg;
                });

                if (functionToInvoke === "addListener" && isPlaceAutocompleteElement(obj)) {
                    const eventName = formattedArgs[0];
                    const handler = formattedArgs[1];
                    const wrappedHandler = (event) => handler(buildPlaceAutocompleteEventPayload(event));
                    obj.addEventListener(eventName, wrappedHandler);
                    return {
                        remove: () => obj.removeEventListener(eventName, wrappedHandler)
                    };
                }

                if (functionToInvoke === "addListener" && obj.content && obj.tagName === "GMP-ADVANCED-MARKER") {
                    const eventName = formattedArgs[0];
                    const handler = formattedArgs[1];

                    // Initialize listener tracking if not exists
                    if (!obj.content._listeners) {
                        obj.content._listeners = {};
                    }

                    // Check and add mouseenter listener
                    if (!obj.content._listeners.mouseenter && "mouseenter" === eventName) {
                        const mouseEnterHandler = function (e) {
                            handler(e);
                        };
                        obj.content.addEventListener('mouseenter', mouseEnterHandler);
                        obj.content._listeners.mouseenter = mouseEnterHandler;
                        return {
                            remove: () => obj.content.removeEventListener('mouseenter', mouseEnterHandler)
                        };
                    }

                    // Check and add mouseleave listener
                    if (!obj.content._listeners.mouseleave && "mouseleave" === eventName) {
                        const mouseLeaveHandler = function (e) {
                            handler(e);
                        };
                        obj.content.addEventListener('mouseleave', mouseLeaveHandler);
                        obj.content._listeners.mouseleave = mouseLeaveHandler;
                        return {
                            remove: () => obj.content.removeEventListener('mouseleave', mouseLeaveHandler)
                        };
                    }
                }

                if (functionToInvoke === "addListenerOnce" && isPlaceAutocompleteElement(obj)) {
                    const eventName = formattedArgs[0];
                    const handler = formattedArgs[1];
                    const onceHandler = (event) => handler(buildPlaceAutocompleteEventPayload(event));
                    obj.addEventListener(eventName, onceHandler, { once: true });
                    return {
                        remove: () => obj.removeEventListener(eventName, onceHandler)
                    };
                }

                try {
                    switch (functionToInvoke) {
                        case "addPolyListener":
                            const path = obj.getPath();
                            const listener = google.maps.event.addListener(path, formattedArgs[0], formattedArgs[1]);
                            return listener;

                        case "blazorGoogleMaps.directionService.route":
                            const responseOrError = await directionService.route.call(obj, formattedArgs[0], formattedArgs[1]);
                            return responseOrError;

                        case "setData":
                            const pointArray = new google.maps.MVCArray();
                            formattedArgs[0].forEach(cord => {
                                const location = cord.hasOwnProperty("weight")
                                    ? { location: new google.maps.LatLng(cord.location.lat, cord.location.lng), weight: cord.weight }
                                    : new google.maps.LatLng(cord.lat, cord.lng);
                                pointArray.push(location);
                            });
                            return obj.setData(pointArray);

                        case "getDirections":
                            const dirRequestOptions = formattedArgs[0];
                            const result = obj[functionToInvoke]();
                            const jsonRest = extendableStringify(cleanDirectionResult(result, dirRequestOptions));
                            return jsonRest;

                        case "getProjection":
                            const projection = obj[functionToInvoke](...formattedArgs);
                            addMapObject(restArgs[0], projection);
                            return;

                        case "createPath":
                            const pathProjection = obj.getPath();
                            addMapObject(restArgs[0], pathProjection);
                            return;

                        case "fromLatLngToPoint":
                            return obj[functionToInvoke](formattedArgs[0]);

                        case "google.maps.marker.PinElement":
                            return new google.maps.marker.PinElement(formattedArgs[0]);

                        case "addListenerOnce":
                            return new google.maps.event.addListenerOnce(obj, formattedArgs[0], formattedArgs[1]);

                        case "getPaths":
                            const paths = obj[functionToInvoke](...formattedArgs);
                            return paths.getArray().map(coords => coords.getArray());

                        case "removeAllFeatures":
                            obj.forEach(feature => obj.remove(feature));
                            return null;

                        case "overrideStyle":
                            const featureId = restArgs[0].replace(/"/g, "");
                            const feature = mapObjects[featureId];
                            const data = mapObjects[objectId];
                            const request = tryParseJson(restArgs[1]);
                            return data.overrideStyle(feature, request);

                        case "setStyle":
                            if (typeof restArgs[0] === 'string') {
                                return obj.setStyle(formattedArgs[0]);
                            }

                            //JsCallableFunc
                            const callback = restArgs[0];
                            obj.setStyle(feature => {
                                const uuid = feature.getProperty("UUID");
                                if (typeof uuid !== 'string')
                                    return;
                                let style = callback.invokeMethod("Invoke", `["${uuid}"]`, null);
                                return style;
                            });
                            return;

                        case "setStyleCallback":
                            const jsFuncName = restArgs[0];
                            //name could be my.namespace.func so split and check function exists
                            const callbackFunc = jsFuncName.split('.').reduce((obj, key) => {
                                return (obj && obj[key] !== undefined) ? obj[key] : undefined;
                            }, window);
                            if (typeof callbackFunc !== 'function')
                                throw new Error(`callback function for setStyle (${jsFuncName}) is not a function, it's '${typeof (callbackFunc)}'`);
                            const map = obj.map;
                            obj.setStyle(f => callbackFunc(map, f));
                            return;

                        case "getFeatureById":
                            const foundFeature = obj.getFeatureById(...formattedArgs);
                            const featureUuid = foundFeature != null ? foundFeature.getProperty("UUID") : null;
                            return featureUuid;

                        default:
                            if (google.maps.places !== undefined && obj instanceof google.maps.places.Place) {
                                // Handle static methods on Place class
                                const placeStaticMethods = ['searchByText', 'searchNearby'];
                                if (placeStaticMethods.includes(functionToInvoke)) {
                                    const result = await google.maps.places.Place[functionToInvoke](formattedArgs[0]);
                                    if (result && Array.isArray(result.places)) {
                                        return { places: result.places.map(p => normalizePlaceObject(p)) };
                                    }
                                    return result;
                                }

                                const result = obj[functionToInvoke](...formattedArgs);
                                if (result && typeof result.then === "function") {
                                    const awaited = await result;
                                    return normalizePlaceObject(awaited ?? obj);
                                }
                                if (result && typeof result === "object") {
                                    return normalizePlaceObject(result);
                                }
                                return normalizePlaceObject(obj);
                            }

                            if (google.maps.places !== undefined && obj instanceof google.maps.places.AutocompleteService ||
                                (google.maps.places !== undefined && obj instanceof google.maps.places.PlacesService) ||
                                obj instanceof google.maps.Geocoder) {
                                return new Promise((resolve, reject) => {
                                    obj[functionToInvoke](formattedArgs[0], (result, status) => {
                                        if (obj instanceof google.maps.places.AutocompleteService) {
                                            resolve({ predictions: result, status: status });
                                        } else {
                                            resolve({ results: result, status: status });
                                        }
                                    });
                                });
                            } else {
                                if (functionToInvoke === "remove" && typeof obj.remove !== "function") {
                                    this.disposeObject(objectId);
                                    return null;
                                }
                                const result = obj[functionToInvoke](...formattedArgs);
                                if (result && typeof result === "object") {
                                    if (result.hasOwnProperty("geocoded_waypoints") && result.hasOwnProperty("routes")) {
                                        return extendableStringify(cleanDirectionResult(result));
                                    }
                                    if ("getArray" in result) {
                                        return result.getArray();
                                    }
                                    if (functionToInvoke === "addListener") {
                                        return result;
                                    }
                                    if (functionToInvoke === "addGeoJson") {
                                        return result.map(feature => {
                                            const uuid = this.addObject(feature);
                                            feature.setProperty("UUID", uuid);
                                            return uuid;
                                        });
                                    }
                                    if ("get" in result) {
                                        return result.get("guidString");
                                    } else if ("dotnetTypeName" in result) {
                                        return extendableStringify(result, getCircularReplacer());
                                    } else {
                                        return JSON.parse(extendableStringify(result, getCircularReplacer()));
                                    }
                                } else if (functionToInvoke === "remove") {
                                    this.disposeObject(objectId);
                                } else {
                                    return result;
                                }
                            }
                    }
                } catch (e) {
                    console.log(e);
                    console.log(`\nfunctionToInvoke: ${functionToInvoke}\nargs: ${JSON.stringify(args2)}\n`);
                }
            },

            //Function could be extended in future: at the moment it is scoped for
            //simple "Get" and "Set" properties of multiple objects of the same type
            invokeMultiple: async function (args) {
                const guids = JSON.parse(args[0]);
                const otherArg = args[1];
                const args2 = args.slice(2).map(arg => tryParseJson(arg));

                const results = {};

                // Collect promises
                const promises = guids.map((guid, index) => {
                    const args3 = [guid, otherArg, args2[index]];
                    const result = blazorGoogleMaps.objectManager.invoke(args3, [args2[index]]);

                    // Return a promise that resolves to the result
                    return Promise.resolve(result).then(resolvedResult => {
                        results[guid] = resolvedResult;
                    });
                });

                // Await all promises concurrently
                await Promise.all(promises);

                return results;
            },
            invokeWithReturnedObjectRef: async function (args) {
                const result = await blazorGoogleMaps.objectManager.invoke(args);
                const uuid = uuidv4();
                // This is needed to be able to remove events from map
                addMapObject(uuid, result)

                return uuid;
            },
            drawingManagerOverlaycomplete: function (args) {
                const [uuid, act] = args;
                const drawingManager = mapObjects[uuid];

                google.maps.event.addListener(drawingManager, "overlaycomplete", event => {
                    const overlayUuid = uuidv4();
                    addMapObject(overlayUuid, event.overlay)

                    const returnObj = extendableStringify([{ type: event.type, uuid: overlayUuid.toString() }]);

                    act.invokeMethodAsync("Invoke", returnObj, uuid);
                });
            },

            invokeMultipleWithReturnedObjectRef: function (args) {

                const guids = args[0];
                const otherArgs = args.slice(1, -1);
                const what = args[args.length - 1];

                const results = {};

                for (let i = 0; i < guids.length; i++) {
                    const uuid = uuidv4();
                    const args2 = [...guids[i], ...otherArgs, what[i]];

                    results[uuid] = blazorGoogleMaps.objectManager.invoke(args2);
                }

                return results;
            },

            //add event listeners to multiple objects of the same type
            addMultipleListeners: async function (args) {
                const guids = JSON.parse(args[0]);
                const eventName = args[1];
                const parsedEventName = tryParseJson(eventName);
                const args2 = args.slice(2).map(arg => tryParseJson(arg));

                // Using Promise.all to handle multiple async operations if needed
                await Promise.all(guids.map((guid, index) => {
                    const additionalArgs = Array.isArray(args2[index]) ? args2[index] : [args2[index]];
                    const args3 = [guid, "addListener", eventName, ...additionalArgs];

                    return blazorGoogleMaps.objectManager.invoke(args3, [parsedEventName, ...additionalArgs]);
                }));

                return true;
            },

            readObjectPropertyValue: function (args) {
                const [objectId, property] = args;
                const obj = mapObjects[objectId];

                return obj?.[property];
            },

            readObjectPropertyValueWithReturnedObjectRef: function (args) {

                const [objectId, property] = args;
                const obj = mapObjects[objectId];
                const result = obj?.[property];
                const uuid = uuidv4();

                addMapObject(uuid, result)

                return uuid;
            },

            readObjectPropertyValueAndMapToArray: function (args) {
                const [objectId, property, propsJson] = args;
                const obj = mapObjects[objectId];
                let result = obj?.[property];
                const props = tryParseJson(propsJson);

                if (result && Array.isArray(result)) {
                    props.forEach(prop => {
                        result = result.map(item => item?.[prop]);
                    });
                }

                return result;
            },

            readPlaceAutocompleteInputValue: function (guid) {
                const elem = mapObjects[guid];
                if (!elem) return null;
                if (typeof elem.value === "string") return elem.value;
                if (typeof elem.inputValue === "string") return elem.inputValue;
                const input = elem.querySelector?.("input") || elem.shadowRoot?.querySelector?.("input");
                return input?.value ?? null;
            },

            //based on https://googlemaps.github.io/js-markerclusterer/
            createClusteringMarkers(guid, mapGuid, markers, options) {
                const map = mapObjects[mapGuid];

                const originalMarkers = markers.map((marker, i) => {
                    return mapObjects[marker.guid];
                });

                const markerClustererOptions = {
                    map: map,
                    markers: originalMarkers,
                };

                if (options && options.rendererObjectName) {
                    const splits = options.rendererObjectName.split(".");
                    try {
                        let renderer = window[splits[0]];
                        for (let i = 1, len = splits.length; i < len; i++) {
                            renderer = renderer[splits[i]];
                        }
                        markerClustererOptions.renderer = renderer;
                    } catch (e) {
                        console.log(e);
                    }
                }

                if (options && options.algorithmObjectName) {
                    const splits = options.algorithmObjectName.split(".");
                    try {
                        let algorithm = window[splits[0]];
                        for (let i = 1, len = splits.length; i < len; i++) {
                            algorithm = algorithm[splits[i]];
                        }
                        markerClustererOptions.algorithm = algorithm;
                    } catch (e) {
                        console.log(e);
                    }
                }

                if (options && !options.zoomOnClick) {
                    markerClustererOptions.onClusterClick = () => { };
                }

                const markerCluster = new markerClusterer.MarkerClusterer(markerClustererOptions);

                /*        const newMarkers = trees.map(({ geometry }, i) => new google.maps.Marker({
                            position: {
                                lat: geometry.coordinates[1],
                                lng: geometry.coordinates[0],
                            },
                            label: labels[i % labels.length],
                            map,
                        }));
                        const markerCluster = new markerClusterer.MarkerClusterer({
                            map: map,
                            markers: newMarkers
                        });
                */
                addMapObject(guid, markerCluster)
            },

            removeClusteringMarkers(guid, markers, noDraw) {
                const originalMarkers = markers.map((marker, i) => {
                    return mapObjects[marker.guid];
                });

                mapObjects[guid].removeMarkers(originalMarkers, noDraw);
            },

            addClusteringMarkers(guid, markers, noDraw) {
                const originalMarkers = markers.map((marker, i) => {
                    return mapObjects[marker.guid];
                });

                mapObjects[guid].addMarkers(originalMarkers, noDraw);
            },
            updateAdvancedComponent: function (id, options, callbackRef) {
                const collisionBehaviorMapping = [
                    google.maps.CollisionBehavior.REQUIRED,
                    google.maps.CollisionBehavior.REQUIRED_AND_HIDES_OPTIONAL,
                    google.maps.CollisionBehavior.OPTIONAL_AND_HIDES_LOWER_PRIORITY,
                ];

                const {
                    position,
                    title,
                    zIndex,
                    gmpClickable,
                    gmpDraggable,
                    collisionBehavior,
                    mapId,
                    componentId,
                } = options;

                const invokeCallback = (method, ...args) => {
                    callbackRef?.invokeMethodAsync(method, ...args);
                };

                const setupClickListener = (marker, isEnabled) => {
                    if (isEnabled) {
                        marker.clickListener = marker.addListener("click", () => {
                            invokeCallback('OnMarkerClicked', id);
                        });
                    } else if (marker.clickListener) {
                        google.maps.event.removeListener(marker.clickListener);
                        delete marker.clickListener;
                    }
                };

                const setupDragListener = (marker, isEnabled) => {
                    if (isEnabled) {
                        marker.dragListener = marker.addListener("dragend", (event) => {
                            invokeCallback('OnMarkerDrag', id, marker.position);
                        });
                    } else if (marker.dragListener) {
                        google.maps.event.removeListener(marker.dragListener);
                        delete marker.dragListener;
                    }
                };

                const setupMouseOverListener = (marker, isEnabled) => {
                    if (isEnabled) {
                        marker.mouseOverListener = marker.addListener("mouseover", () => {
                            invokeCallback('OnMarkerMouseOver', id);
                        });
                    } else if (marker.mouseOverListener) {
                        google.maps.event.removeListener(marker.mouseOverListener);
                        delete marker.mouseOverListener;
                    }
                };

                const setupMouseOutListener = (marker, isEnabled) => {
                    if (isEnabled) {
                        marker.mouseOutListener = marker.addListener("mouseout", () => {
                            invokeCallback('OnMarkerMouseOut', id);
                        });
                    } else if (marker.mouseOutListener) {
                        google.maps.event.removeListener(marker.mouseOutListener);
                        delete marker.mouseOutListener;
                    }
                };

                const existingMarker = mapObjects[id];
                if (existingMarker) {
                    const clickChanged = existingMarker.gmpClickable !== gmpClickable;
                    const dragChanged = existingMarker.gmpDraggable !== gmpDraggable;

                    Object.assign(existingMarker, {
                        position,
                        title,
                        zIndex,
                        gmpClickable,
                        gmpDraggable,
                        collisionBehavior: collisionBehaviorMapping[collisionBehavior],
                    });

                    if (clickChanged) setupClickListener(existingMarker, gmpClickable);
                    if (dragChanged) setupDragListener(existingMarker, gmpDraggable);
                    if (clickChanged) setupMouseOverListener(existingMarker, gmpClickable);
                    if (clickChanged) setupMouseOutListener(existingMarker, gmpClickable);
                    return;
                }

                const map = mapObjects[mapId];

                const content = document.querySelector(`#${componentId}`);
                if (!content) {
                    console.warn("Marker tried to render without a target component");
                    return;
                }

                const advancedMarkerElement = new google.maps.marker.AdvancedMarkerElement({
                    map,
                    content,
                    position,
                    title,
                    zIndex,
                    gmpClickable,
                    gmpDraggable,
                    collisionBehavior: collisionBehaviorMapping[collisionBehavior],
                });

                advancedMarkerElement.guidString = id;

                setupClickListener(advancedMarkerElement, gmpClickable);
                setupDragListener(advancedMarkerElement, gmpDraggable);
                setupMouseOverListener(advancedMarkerElement, gmpClickable);
                setupMouseOutListener(advancedMarkerElement, gmpClickable);

                addMapObject(id, advancedMarkerElement);
            },
            disposeAdvancedMarkerComponent: function (id) {
                const existingMarker = mapObjects[id];
                if (!existingMarker) return;
                existingMarker.map = null;
                this.disposeObject(id);
            },
            updatePolygonComponent: function (id, options, callbackRef) {
                const {
                    paths,
                    strokeColor,
                    strokeOpacity,
                    strokeWeight,
                    fillColor,
                    fillOpacity,
                    clickable,
                    editable,
                    visible,
                    draggable,
                    mapId
                } = options;

                const map = mapObjects[mapId];
                const invokeCallback = (method, ...args) => {
                    callbackRef?.invokeMethodAsync(method, ...args);
                };

                const setupClickListener = (polygon, clickable) => {
                    // Remove existing listener if present
                    if (polygonClickListeners.has(polygon)) {
                        google.maps.event.removeListener(polygonClickListeners.get(polygon));
                        polygonClickListeners.delete(polygon);
                    }

                    // Add listener if polygon is clickable
                    if (clickable) {
                        const listener = polygon.addListener("click", () => {
                            invokeCallback('OnPolygonClicked', id);
                        });
                        polygonClickListeners.set(polygon, listener);
                    }
                };

                const setupDragListener = (polygon, isEnabled) => {
                    // Remove existing listener if present
                    if (polygonDragListeners.has(polygon)) {
                        google.maps.event.removeListener(polygonDragListeners.get(polygon));
                        polygonDragListeners.delete(polygon);
                    }

                    // Add listener if polygon is draggable
                    if (isEnabled) {
                        const listener = polygon.addListener("dragend", () => {
                            const updatedPaths = [];
                            const allPaths = polygon.getPaths();
                            for (let i = 0; i < allPaths.getLength(); i++) {
                                const subPath = allPaths.getAt(i);
                                const latLngs = [];
                                for (let j = 0; j < subPath.getLength(); j++) {
                                    const latLng = subPath.getAt(j);
                                    latLngs.push({ lat: latLng.lat(), lng: latLng.lng() });
                                }
                                updatedPaths.push(latLngs);
                            }
                            invokeCallback('OnPolygonPathChange', id, updatedPaths);
                        });
                        polygonDragListeners.set(polygon, listener);
                    }
                };

                const setupPathChangeListener = (polygon, editable) => {
                    const paths = polygon.getPaths();

                    const returnPaths = () => {
                        const updatedPaths = [];
                        const allPaths = polygon.getPaths();
                        for (let i = 0; i < allPaths.getLength(); i++) {
                            const subPath = allPaths.getAt(i);
                            const latLngs = [];
                            for (let j = 0; j < subPath.getLength(); j++) {
                                const latLng = subPath.getAt(j);
                                latLngs.push({ lat: latLng.lat(), lng: latLng.lng() });
                            }
                            updatedPaths.push(latLngs);
                        }
                        invokeCallback("OnPolygonPathChange", polygon.guidString, updatedPaths);
                    };

                    for (let i = 0; i < paths.getLength(); i++) {
                        const path = paths.getAt(i);

                        if (editable) {
                            // Add listeners if not already added
                            if (!path.insertListener) {
                                path.insertListener = path.addListener("insert_at", returnPaths);
                            }
                            if (!path.setListener) {
                                path.setListener = path.addListener("set_at", returnPaths);
                            }
                            if (!path.removeListener) {
                                path.removeListener = path.addListener("remove_at", returnPaths);
                            }
                        } else {
                            // Remove if no longer editable
                            if (path.insertListener) {
                                google.maps.event.removeListener(path.insertListener);
                                delete path.insertListener;
                            }
                            if (path.setListener) {
                                google.maps.event.removeListener(path.setListener);
                                delete path.setListener;
                            }
                            if (path.removeListener) {
                                google.maps.event.removeListener(path.removeListener);
                                delete path.removeListener;
                            }
                        }
                    }
                };

                const existingPolygon = mapObjects[id];

                if (existingPolygon) {
                    const dragChanged = existingPolygon.getDraggable() !== draggable;

                    existingPolygon.setOptions({
                        paths,
                        strokeColor,
                        strokeOpacity,
                        strokeWeight,
                        fillColor,
                        fillOpacity,
                        clickable,
                        editable,
                        draggable,
                        visible
                    });

                    setupClickListener(existingPolygon, clickable);
                    setupPathChangeListener(existingPolygon, editable);
                    if (dragChanged) setupDragListener(existingPolygon, draggable);
                    return;
                }

                const polygon = new google.maps.Polygon({
                    paths,
                    strokeColor,
                    strokeOpacity,
                    strokeWeight,
                    fillColor,
                    fillOpacity,
                    clickable,
                    editable,
                    draggable,
                    visible,
                    map
                });

                polygon.guidString = id;

                setupClickListener(polygon, clickable)
                setupPathChangeListener(polygon, editable);
                setupDragListener(polygon, draggable);

                addMapObject(id, polygon);
            },

            disposePolygonComponent: function (id) {
                const polygon = mapObjects[id];
                if (!polygon) return;

                // Remove path listeners
                const paths = polygon.getPaths();
                for (let i = 0; i < paths.getLength(); i++) {
                    const path = paths.getAt(i);
                    if (path.insertListener) google.maps.event.removeListener(path.insertListener);
                    if (path.setListener) google.maps.event.removeListener(path.setListener);
                    if (path.removeListener) google.maps.event.removeListener(path.removeListener);
                }

                // Remove click listeners
                if (polygonClickListeners.has(polygon)) {
                    google.maps.event.removeListener(polygonClickListeners.get(polygon));
                    polygonClickListeners.delete(polygon);
                }

                // Remove drag listeners
                if (polygonDragListeners.has(polygon)) {
                    google.maps.event.removeListener(polygonDragListeners.get(polygon));
                    polygonDragListeners.delete(polygon);
                }

                polygon.setMap(null);
                this.disposeObject(id);
            },

            addHeatmap: function (id, mapId, options, callbackRef) {
                const map = mapObjects[mapId];
                if (!map) return;

                const heatmap = new google.maps.visualization.HeatmapLayer({
                    data: (options.data || []).map(p => ({
                        location: new google.maps.LatLng(p.location.lat, p.location.lng),
                        weight: p.weight
                    })),
                    radius: options.radius,
                    opacity: options.opacity,
                    dissipating: options.dissipating,
                    maxIntensity: options.maxIntensity,
                    gradient: options.gradient || null,
                    map: map
                });

                heatmap.guidString = id;

                addMapObject(id, heatmap);
            },

            updateHeatmap: function (id, options, callbackRef) {
                const heatmap = mapObjects[id];
                if (!heatmap) return;

                const data = (options.data || []).map(p => ({
                    location: new google.maps.LatLng(p.location.lat, p.location.lng),
                    weight: p.weight
                }));

                heatmap.setOptions({
                    data: data,
                    radius: options.radius,
                    opacity: options.opacity,
                    dissipating: options.dissipating,
                    maxIntensity: options.maxIntensity,
                    gradient: options.gradient || null
                });
            },

            removeHeatmap: function (id) {
                const heatmap = mapObjects[id];
                if (!heatmap) return;

                heatmap.setMap(null);
                this.disposeObject(id);
            }
        }

    };


}();
